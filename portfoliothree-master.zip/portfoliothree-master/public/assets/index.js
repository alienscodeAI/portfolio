import bgOne from "../assets/1.jpg"
import bgTwo from "../assets/2.jpg"
import bgThree from "../assets/3.jpg"
import bgFour from "../assets/4.jpg"

export {bgOne,bgTwo,bgThree,bgFour}